from django.db import models
from django.core.validators import RegexValidator

# Create your models here.

class LivroInfo(models.Model):
    msg_erro = {
            'null':'Este campo não pode ser nulo!!!',
            'blank':'Este campo não pode ser deixado em branco',
            'invalid':'Este não é um valor válido',
            }

    titulo = models.CharField(max_length=200, error_messages=msg_erro) 
    ISBN = models.CharField(
            max_length=23,
            validators = [
                RegexValidator(
                    regex='[0-9]{1,3}\-[0-9]{1,2}\-[0-9]{1,7}-[0-9]{1,6}-[0-9]',
                    message='O formato do campo é inválido',
                    )
                ],
            null = True,
            blank=True,
            default='978-85-7522-730-5',
            error_messages=msg_erro,
            )
    autor = models.CharField(max_length=200, null=True, blank=True, 
            error_messages=msg_erro)
    editora = models.CharField(max_length=100, null=True, blank=True,
            error_messages=msg_erro)
    edicao = models.IntegerField(null=True, blank=True, 
            error_messages=msg_erro)
    numero_paginas = models.IntegerField(null=True, blank=True,
            error_messages=msg_erro)
    descricao_rapida = models.TextField(max_length=500, null=True, blank=True,
            error_messages=msg_erro)

