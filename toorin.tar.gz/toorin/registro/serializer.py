from rest_framework import serializers
from .models import LivroInfo

class LivroInfoSerializer(serializers.ModelSerializer):
    class Meta:
        msg_erro = {
            'null':'Este campo não pode ser nulo!!!',
            'blank':'Este campo não pode ser deixado em branco',
            'invalid':'Este não é um valor válido',
            }
        model = LivroInfo
        fields = '__all__'
        extra_kwargs = {
                'titulo':{
                    'label':'Título',
                    'error_messages':msg_erro,
                    },
                'isbn':{
                    'label':'ISBN',
                    'help_text':'Exemplo: 978-85-7522-730-5',
                    'error_messages':msg_erro,
                    },
                'edicao':{
                    'label':'Edição',
                    'error_messages':msg_erro,
                    },
                'numero_paginas':{
                    'label':'Número de páginas',
                    'error_messages':msg_erro,
                    },
                'descricao_paginas':{
                    'label':'Descrição rápida',
                    },
                }
