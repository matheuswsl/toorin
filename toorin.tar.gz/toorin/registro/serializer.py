from rest_framework import serializers
from .models import LivroInfo

class LivroInfoSerializer(serializers.ModelSerializer):
    class Meta:
        model = LivroInfo
        fields = '__all__'
