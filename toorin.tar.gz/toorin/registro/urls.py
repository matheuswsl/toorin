from django.urls import path
from .views import LivroInfoAPIView

urlpatterns = [
        path('registro/', LivroInfoAPIView.as_view()),
        path('registro/<int:id>/', LivroInfoAPIView.as_view()),
        ]
